package com.tc.entity;

public class Link  //链表
{
 	class Node  //节点
 	{
  		private String msg;
  		private Node next;
 		//构造
	  public Node(String msg) {
	    this.msg = msg;
	   }
	   //setter、getter
	   public String getMsg() {
	    return msg;
	   }
	   public void setMsg(String msg) {
	    this.msg = msg;
	   }
	   public Node getNext() {
	    return next;
	   }
	   public void setNext(Node next) {
	    this.next = next;
	   }  	
	//添加节点
  	public void addNode(Node newNode)
  	{
  	 	if(this.next==null)
   		{
    			this.next=newNode;
   		}
  		 else
   		{
    			this.next.addNode(newNode); //递归实现，以下内部类中的很多方法都是用递归实现的
   		}
  	}
  	//判断节点是否存在
 	public boolean containsNode(String temp)
  	{
   		if(temp.equals(this.msg))
   		{
    			return true;
   		}
   		else
   		{
   			 if(this.next==null)
     			return false;
    			else
     			return this.next.containsNode(temp);
   		}
  	}
  	//根据索引值获得节点的数据
  	public String getNode(int index)
  	{
   		if(Link.this.flag++==index)
   		{
    			return this.msg;
   		}
   		else
   		{
    			return this.next.getNode(index);
   		}
  	}
  	//指定节点用新数据替换
 	 public void repalce(String newMsg,int index)
  	{
  		 if(Link.this.flag++==index)
   		{
    			this.setMsg(newMsg);
   		}
   		else
   		{
    			this.next.repalce(newMsg, index);
   		}
  	}
  	//删除节点
  	public void removeNode(Node previous,String temp)
  	{
   		if(temp.equals(this.msg))
   		{
    			previous.next=this.next;
   		}
   		else
   		{
    			if(this.next==null)
    			{
     			return ;
   			 }
    			this.next.removeNode(this, temp);
   		}
  	}
 }
//===============以上是内部类========================
 	private Node root;   //根节点
 	private int size=0;  //记录节点个数
 	private int flag;
 	//在链表末尾添加节点
 	public void add(String msg)
 	{
 		 Node newNode=new Node(msg);
  		if(this.root==null)
  		{
   			this.root=newNode;
  		}
  		else
  		{
   			this.root.addNode(newNode);
  		}
  		this.size++;
 	}
 	//获得链表的长度
 	public int size()
 	{
  		return this.size;
 	}
 	//判断链表是否为空
 	public boolean isEmpty()
 	{
  		if(this.size==0)
   			return true;
  		else
   			return false;
 	}
 	//判断链表中某一数据是否存在
 	public boolean contains(String temp) //判断是否存在函数，该数据类型必须有比较函数
 	{
  		if(this.root==null)
  		{
   			return false;
  		}
 		else
 		{
   			return this.root.containsNode(temp);
  		}
 	}
 	//根据索引取得元素
 	public String get(int index)
 	{
  		this.flag=0;
  		if(index>this.size-1)  //索引值超出维度，则返回空
  		{
   			System.out.println("索引超出维度！");
   			return null;
  		}
  		else
  		{
   			return this.root.getNode(index);
  		}
 	}
 	//用新数据替换指定位置的旧数据
 	public void replace(String newMsg,int index)
 	{
  		this.flag=0;
  		if(index>this.size-1)
  		{
   			System.out.println("索引超出维度！");
   			return ;
  		}
  		else
  		{
   			this.root.repalce(newMsg, index);
  		}
 	}
 	//删除链表中指定内容
	public void remove(String temp)
 	{
  		if(this.root==null)
  		{
   			return ;
  		}else
  		{
   			if(temp.equals(this.root.msg)&&this.root.next==null)
   			{
   				 this.root=null;
   			}
   			else if(temp.equals(this.root.msg)&&this.root.next!=null)
   			{
    				this.root=this.root.next;
   			}
   			else
   			{
    				this.root.next.removeNode(this.root,temp);
   			}
  		}
 	}
 	//清空链表
 	public void clear()
 	{
  		this.root=null;
  		this.size=0;
 	}
}
